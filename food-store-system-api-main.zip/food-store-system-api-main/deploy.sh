PROVIDER="registry.gitlab.com"
REPO="food-store-system-api"
ORGANIZATION_PROD="drivezer01"
BRANCH=$(git branch | sed -n -e 's/^\* \(.*\)/\1/p')

docker login registry.gitlab.com -u drivezer01 -p glpat-wY6i7ihyf5i9xtwR4xSt

if [[ $BRANCH == *"main"* ]]; then
    if [[ $OSTYPE == "darwin"* ]]; then
        docker build -f Dockerfile -t $PROVIDER/$ORGANIZATION_PROD/$REPO --platform=linux/amd64 .
    else
        docker build -f Dockerfile -t $PROVIDER/$ORGANIZATION_PROD/$REPO .
    fi
    docker push $PROVIDER/$ORGANIZATION_PROD/$REPO
    curl -X POST "https://portainer.iotechsoft.com/api/webhooks/94d6ebfa-582c-4209-a656-4875a7bd0926"
    docker rmi $PROVIDER/$ORGANIZATION_PROD/$REPO
else
    echo "******"
fi
