export const SECRET_KEY = {
    secret: 'FoodStoreSystem'
};