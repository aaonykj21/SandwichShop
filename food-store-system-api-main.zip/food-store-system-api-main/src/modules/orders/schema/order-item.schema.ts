import { Schema } from 'mongoose';

export const OrderItemSchema = new Schema(
    {
        order_step_1: String,
        order_step_2: [Number],
        order_step_3: [Number],
        order_step_4: [Number],
        order_step_5: [Number],
        order_price: Number,
        order_qty: Number,
    },
    {
        timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
    },
);
