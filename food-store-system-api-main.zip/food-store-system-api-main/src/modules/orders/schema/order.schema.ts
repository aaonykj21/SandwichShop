import { Schema } from 'mongoose';
import { OrderItemSchema } from './order-item.schema';

export const OrderSchema = new Schema(
    {
        order_number: String,
        order_items: [OrderItemSchema],
        order_status: Number,
        order_payment_type: String,
        order_payment_slip: String,
    },
    {
        timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
    },
);
