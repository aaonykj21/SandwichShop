import { Body, Controller, Delete, Get, Param, Post, Put, Req } from '@nestjs/common';
import { OrdersService } from '../service/orders.service';
import { OrderModel } from '../model/order.model';
import { Public } from 'src/modules/auth/jwt/jwt-auth.guard';

@Public()
@Controller('orders')
export class OrdersController {
    constructor(
        private _orders: OrdersService,
    ) { }

    @Get()
    async findAll(@Req() req: any) {
        return await this._orders.findAll(req.query);
    }

    @Get(':orderId')
    async findOne(@Param('orderId') orderId: string) {
        return await this._orders.findOne(orderId);
    }

    @Post()
    async create(@Body() data: OrderModel) {
        const itemOrder = await this._orders.findAll();
        // data.order_number = `OR${new Date().getFullYear()}${('00').substring(0, ('00').length - (`${new Date().getMonth()}`).length) + `${new Date().getMonth()}`}-${('000000').substring(0, ('000000').length - (`${itemOrder.total + 1}`).length) + `${itemOrder.total + 1}`}`;
        data.order_number = `${('0000').substring(0, ('0000').length - (`${itemOrder.total + 1}`).length) + `${itemOrder.total + 1}`}`;
        return await this._orders.create(data);
    }

    @Put(':orderId')
    async update(@Param('orderId') orderId: string, @Body() data: OrderModel) {
        return await this._orders.update(orderId, data);;
    }

    @Delete(':orderId')
    async delete(@Param('orderId') orderId: string) {
        return await this._orders.delete(orderId);
    }
}
