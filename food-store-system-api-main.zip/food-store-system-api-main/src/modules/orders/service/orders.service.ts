import { Injectable } from '@nestjs/common';
import { OrderModel } from '../model/order.model';
import { MongoCRUD } from 'src/modules/shared/mongo-curd';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';

@Injectable()
export class OrdersService extends MongoCRUD<OrderModel> {
    constructor(
        @InjectModel('orders') public model: Model<OrderModel>,
    ) {
        super(model);
    }
}
