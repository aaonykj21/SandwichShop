import { Timestamps } from '../../shared/interfaces/timestamps.model';

export class OrderItemModel extends Timestamps {
    order_step_1: string;
    order_step_2: [number];
    order_step_3: [number];
    order_step_4: [number];
    order_step_5: [number];
    order_price: number;
    order_qty: number;
}
