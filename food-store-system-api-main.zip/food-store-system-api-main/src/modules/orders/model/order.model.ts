import { Timestamps } from '../../shared/interfaces/timestamps.model';
import { OrderItemModel } from './order-item.model';

export class OrderModel extends Timestamps {
    order_number: string;
    order_items: [OrderItemModel];
    order_status: number; // 0 = สั่ง, 1 = กำลังทำ, 2 = เสร็จแล้วรอเซิฟ, 3 = เซิฟแล้ว
    order_payment_type: string;
    order_payment_slip: string;
}
