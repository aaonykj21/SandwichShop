import { Timestamps } from '../../shared/interfaces/timestamps.model';

export class StockModel extends Timestamps {
    stock_step: number;
    stock_index: number;
    stock_qty: number;
}
