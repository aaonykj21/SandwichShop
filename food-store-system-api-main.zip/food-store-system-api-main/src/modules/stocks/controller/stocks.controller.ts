import { Body, Controller, Delete, Get, Param, Post, Put, Req } from '@nestjs/common';
import { Public } from 'src/modules/auth/jwt/jwt-auth.guard';
import { StockModel } from '../model/stock.model';
import { StocksService } from '../service/stocks.service';

@Public()
@Controller('stocks')
export class StocksController {
    constructor(
        private _stocks: StocksService,
    ) {
        this.checkDefaultStock();
    }

    async checkDefaultStock() {
        const { total } = await this._stocks.findAll();
        if (total === 0) {
            const items = [
                {
                    stock_step: 1,
                    stock_index: 0,
                    stock_qty: 20
                },
                {
                    stock_step: 1,
                    stock_index: 1,
                    stock_qty: 20
                },
                {
                    stock_step: 1,
                    stock_index: 2,
                    stock_qty: 20
                },
                {
                    stock_step: 1,
                    stock_index: 3,
                    stock_qty: 20
                },
                {
                    stock_step: 2,
                    stock_index: 0,
                    stock_qty: 20
                },
                {
                    stock_step: 2,
                    stock_index: 1,
                    stock_qty: 20
                },
                {
                    stock_step: 2,
                    stock_index: 2,
                    stock_qty: 20
                },
                {
                    stock_step: 2,
                    stock_index: 3,
                    stock_qty: 20
                },
                {
                    stock_step: 2,
                    stock_index: 4,
                    stock_qty: 20
                },
                {
                    stock_step: 2,
                    stock_index: 5,
                    stock_qty: 20
                },
                {
                    stock_step: 3,
                    stock_index: 0,
                    stock_qty: 20
                },
                {
                    stock_step: 3,
                    stock_index: 1,
                    stock_qty: 20
                },
                {
                    stock_step: 3,
                    stock_index: 2,
                    stock_qty: 20
                },
                {
                    stock_step: 3,
                    stock_index: 3,
                    stock_qty: 20
                },
                {
                    stock_step: 3,
                    stock_index: 4,
                    stock_qty: 20
                },
                {
                    stock_step: 3,
                    stock_index: 5,
                    stock_qty: 20
                },
                {
                    stock_step: 3,
                    stock_index: 6,
                    stock_qty: 20
                },
                {
                    stock_step: 3,
                    stock_index: 7,
                    stock_qty: 20
                },
                {
                    stock_step: 3,
                    stock_index: 8,
                    stock_qty: 20
                },
                {
                    stock_step: 4,
                    stock_index: 1,
                    stock_qty: 20
                },
                {
                    stock_step: 4,
                    stock_index: 1,
                    stock_qty: 20
                },
                {
                    stock_step: 4,
                    stock_index: 2,
                    stock_qty: 20
                },
                {
                    stock_step: 4,
                    stock_index: 3,
                    stock_qty: 20
                },
                {
                    stock_step: 4,
                    stock_index: 4,
                    stock_qty: 20
                },
                {
                    stock_step: 4,
                    stock_index: 5,
                    stock_qty: 20
                },
                {
                    stock_step: 4,
                    stock_index: 6,
                    stock_qty: 20
                },
                {
                    stock_step: 4,
                    stock_index: 7,
                    stock_qty: 20
                },
                {
                    stock_step: 4,
                    stock_index: 8,
                    stock_qty: 20
                },
                {
                    stock_step: 4,
                    stock_index: 9,
                    stock_qty: 20
                },
                {
                    stock_step: 5,
                    stock_index: 1,
                    stock_qty: 20
                },
                {
                    stock_step: 5,
                    stock_index: 2,
                    stock_qty: 20
                },
                {
                    stock_step: 5,
                    stock_index: 3,
                    stock_qty: 20
                },
            ];
            await this._stocks.model.create(items);
        }
    }

    @Get()
    async findAll(@Req() req: any) {
        return await this._stocks.findAll(req.query);
    }

    @Get(':stockId')
    async findOne(@Param('stockId') stockId: string) {
        return await this._stocks.findOne(stockId);
    }

    @Post()
    async create(@Body() data: StockModel) {
        return await this._stocks.create(data);
    }

    @Put(':stockId')
    async update(@Param('stockId') stockId: string, @Body() data: StockModel) {
        return await this._stocks.update(stockId, data);;
    }

    @Delete(':stockId')
    async delete(@Param('stockId') stockId: string) {
        return await this._stocks.delete(stockId);
    }
}
