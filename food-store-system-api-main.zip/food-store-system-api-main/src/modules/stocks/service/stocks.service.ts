import { Injectable } from '@nestjs/common';
import { StockModel } from '../model/stock.model';
import { InjectModel } from '@nestjs/mongoose';
import { MongoCRUD } from 'src/modules/shared/mongo-curd';
import { Model } from 'mongoose';

@Injectable()
export class StocksService extends MongoCRUD<StockModel> {
    constructor(
        @InjectModel('stocks') public model: Model<StockModel>,
    ) {
        super(model);
    }
}

