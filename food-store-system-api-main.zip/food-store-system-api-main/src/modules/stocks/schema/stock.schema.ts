import { Schema } from 'mongoose';

export const StockSchema = new Schema(
    {
        stock_step: Number,
        stock_index: Number,
        stock_qty: Number,
    },
    {
        timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' },
    },
);
