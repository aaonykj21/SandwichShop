import { Module } from '@nestjs/common';
import { StocksController } from './controller/stocks.controller';
import { StocksService } from './service/stocks.service';
import { MongooseModule } from '@nestjs/mongoose';
import { StockSchema } from './schema/stock.schema';
import { SharedModule } from '../shared/shared.module';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'stocks', schema: StockSchema },
    ]),
    SharedModule,
  ],
  controllers: [StocksController],
  providers: [StocksService],
  exports: [StocksService],
})
export class StocksModule { }
