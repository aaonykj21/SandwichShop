export class ModelServiceMongoDB {
    modelService: any;
    modelName: string;
    countField?: string;
}
