interface ResponseData<T> {
    data: T[],
    total: number
}