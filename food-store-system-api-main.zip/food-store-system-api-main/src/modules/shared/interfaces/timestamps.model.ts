export class Timestamps {
    created_at?: Date; // สร้างวันที่
    updated_at?: Date; // อัพเดทวันที่
    created_by?: string; // สร้างโดย
}