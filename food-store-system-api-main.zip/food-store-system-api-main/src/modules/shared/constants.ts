export class Constants {
    static readonly LIMIT = 100;
    static readonly OFFSET = 0;
}
